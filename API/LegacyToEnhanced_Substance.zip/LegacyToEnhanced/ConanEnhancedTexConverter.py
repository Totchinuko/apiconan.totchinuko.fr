import os
import re
import subprocess

# /!\ Set your path to the Substance Designer folder if its not in the default location
substance_designer = "C:\Program Files\Adobe\Adobe Substance 3D Designer"
# /!\ The rest is fine, don't touch!

# Script Start
dir_path = os.path.dirname(os.path.realpath(__file__))
legacy_path = os.path.join(dir_path, "Legacy")
enhanced_path = os.path.join(dir_path, "Enhanced")
sbsrender_path = os.path.join(substance_designer, "sbsrender.exe")
sbsar_path = os.path.join(dir_path, "ConanEnhancedTexConverter.sbsar")

# Checking path
if(not os.path.exists(sbsar_path)):
    print("Setup is broken, could not find sbsar")
    exit()
if(not os.path.exists(legacy_path)):
    print("Setup is broken, could not find Legacy Folder")
    exit()
if(not os.path.exists(enhanced_path)):
    print("Setup is broken, could not find Enhanced Folder")
    exit()
if(not os.path.exists(sbsrender_path)):
    print("Setup is broken, could not find sbsrender")
    exit()

# Listing conversions
print("Select the graph you wish to run")
print("1. LegacyToEnhancedSkin")
print("2. LegacyToEnhancedArmor")
graph_mode = int(input(">"))
if graph_mode < 1 or graph_mode > 2:
    print("Unknown graph selected")
    exit()

legacy_files = [f for f in os.listdir(legacy_path) if os.path.isfile(os.path.join(legacy_path, f))]
conversion_list = set()
for file in legacy_files:
    name = re.findall("(.+)_(?:M|N|D|TM|O)$", os.path.splitext(file)[0])
    conversion_list.add(name[0])

# Go
for file in conversion_list:
    print("Conversion: "+file)
    command = sbsrender_path + " render --input \"" + sbsar_path + "\" --output-name \"" + file + "_{outputNodeName}\" --output-format \"tga\" --output-path \"" + enhanced_path + "\" --set-value \"$outputsize@11,11\""
    if graph_mode == 1:
        command += " --input-graph \"LegacyToEnhancedSkin\""
    elif graph_mode == 2:
        command += " --input-graph \"LegacyToEnhancedArmor\""

    bcr = False
    ncd = False
    tm = False
    op = False
    if os.path.exists(os.path.join(legacy_path, file + "_D.png")) and os.path.exists(os.path.join(legacy_path, file + "_M.png")):
        command += " --set-entry \"LegacyBaseColor@" + os.path.join(legacy_path, file + "_D.png") + "\""
        command += " --set-entry \"LegacyMask@" + os.path.join(legacy_path, file + "_M.png") + "\""
        bcr = True
    if os.path.exists(os.path.join(legacy_path, file + "_D.tga")) and os.path.exists(os.path.join(legacy_path, file + "_M.tga") and not bcr):
        command += " --set-entry \"LegacyBaseColor@" + os.path.join(legacy_path, file + "_D.tga") + "\""
        command += " --set-entry \"LegacyMask@" + os.path.join(legacy_path, file + "_M.tga") + "\""
        bcr = True
    if os.path.exists(os.path.join(legacy_path, file + "_N.png")):
        command += " --set-entry \"LegacyNormal@" + os.path.join(legacy_path, file + "_N.png") + "\""
        ncd = True
    if os.path.exists(os.path.join(legacy_path, file + "_N.tga") and not ncd):
        command += " --set-entry \"LegacyNormal@" + os.path.join(legacy_path, file + "_N.tga") + "\""
        ncd = True
    if os.path.exists(os.path.join(legacy_path, file + "_TM.png")):
        command += " --set-entry \"LegacyTintmap@" + os.path.join(legacy_path, file + "_TM.png") + "\""
        tm = True
    if os.path.exists(os.path.join(legacy_path, file + "_TM.tga") and not tm):
        command += " --set-entry \"LegacyTintmap@" + os.path.join(legacy_path, file + "_TM.tga") + "\""
        tm = True
    if os.path.exists(os.path.join(legacy_path, file + "_O.png")):
        command += " --set-entry \"LegacyOpacity@" + os.path.join(legacy_path, file + "_O.png") + "\""
        op = True
    if os.path.exists(os.path.join(legacy_path, file + "_O.tga") and not op):
        command += " --set-entry \"LegacyOpacity@" + os.path.join(legacy_path, file + "_O.tga") + "\""
        op = True
    
    if bcr:
        if graph_mode == 1:
            command += " --input-graph-output \"BCR\""
        elif graph_mode == 2:
            command += " --input-graph-output \"BCRO\""
        if not op:
            command += " --set-value \"$IsAlphaOpacity@1\""
    if ncd: 
        command += " --input-graph-output \"NCD_Mask\""
    if tm:
        command += " --input-graph-output \"RGN_Mask\""
    
    subprocess.call(command)
    #print(command)

print("End of Script")